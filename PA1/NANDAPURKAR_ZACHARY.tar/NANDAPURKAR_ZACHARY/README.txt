Zachary Nandapurkar PA1
USC_ID: 1444003540

Server:
python server.py -p 12345 -l blank.txt -h 1


Clients:
python client.py -s localhost -p 12345 -l clientlog.txt -n Zach

python client.py -s localhost -p 12345 -l clientlog2.txt -n Tim